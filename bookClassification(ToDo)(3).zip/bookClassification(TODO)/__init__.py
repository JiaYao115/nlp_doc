'''
@Author: your name
@Date: 2020-04-08 16:16:24
@LastEditTime: 2020-04-08 17:05:33
@LastEditors: Please set LastEditors
@Description: In User Settings Edit
@FilePath: /textClassification/__init__.py
'''
import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)